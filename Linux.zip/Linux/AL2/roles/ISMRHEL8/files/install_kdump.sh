#!/bin/bash
# Install the kdump
sudo yum install kexec-tools -y

#make directory for dump location
mkdir /usr/local/cores

# Edit the grub file and set crashkernel=128
sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="console=tty0 console=ttyS0,115200n8 net.ifnames=0 biosdevname=0 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0/GRUB_CMDLINE_LINUX_DEFAULT="crashkernel=100M console=tty0 console=ttyS0,115200n8 net.ifnames=0 biosdevname=0 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0/g' /etc/default/grub
#restart the instance

#Configure dump location. Default is /var/crash
sed -i 's#path /var/crash#path /usr/local/cores#g' /etc/kdump.conf

# Set kdump service to start when system is rebooted. 
sudo systemctl enable kdump.service

#sudo reboot

#!/bin/bash


# Set Maximum Authentication try to 3
sed -i 's/#MaxAuthTries 6/MaxAuthTries 3/g' /etc/ssh/sshd_config
#Set Maximum Session to 5
sed -i 's/#MaxSessions 10/MaxSessions 5/g' /etc/ssh/sshd_config
#Set Compression to no
sed -i 's/#Compression delayed/Compression no/g' /etc/ssh/sshd_config
#Set AgentForwarding to no
sed -i 's/#AllowAgentForwarding yes/AllowAgentForwarding no/g' /etc/ssh/sshd_config
#Set PermitRootLogin to no
sed -i 's/PermitRootLogin yes/PermitRootLogin no/g' /etc/ssh/sshd_config
#Set ClientAliveInterval to 600
sed -i 's/ClientAliveInterval 180/ClientAliveInterval 600/g' /etc/ssh/sshd_config
#Set TCP Forwarding to no
sed -i 's/#AlloeTcpForwarding yes/AllowTcpForwarding no/g' /etc/ssh/sshd_config
#Set PasswordAuthentication to no
sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/g' /etc/ssh/sshd_config
#Disallow root login
sed -i 's/#PermitRootLogin yes/PermitRootLogin no/g' /etc/ssh/sshd_config
#Comment out GSSAPI related options
sed -i 's/GSSAPIAuthentication yes/#GSSAPIAuthentication yes/g' /etc/ssh/sshd_config
sed -i 's/GSSAPICleanupCredentials no/#GSSAPICleanupCredentials no/g' /etc/ssh/sshd_config

# Allow Public Key Authentication
sed -i 's/#PubkeyAuthentication yes/PubkeyAuthentication yes/g' /etc/ssh/sshd_config


#!/bin/bash

sudo sh ./omsagent-1.14.19-0.universal.x64.sh --install -w <workspace id> -s <shared key> --skip-docker-provider-install
#!/bin/bash

echo "min_rsa_size = 3072" > /etc/crypto-policies/policies/modules/RSA-SIZE.pmod

sudo update-crypto-policies --set FUTURE
